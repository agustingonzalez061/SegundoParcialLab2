using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Sp
{
  public class Banana : Fruta
  {
    protected string _paisOrigen;

    public string Nombre
    {
      get { return "Banana"; }
    }
    public override bool TieneCarozo
    {
      get
      {
        return  false;
      }
    }
    public Banana(string color, double peso, string pais) : base(color, peso)
    {
      this._paisOrigen = pais;
    }
    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Fruta" + Nombre);
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Pais de origen: " + this._paisOrigen);

      return sb.ToString();
    }
    public override string ToString()
    {
      return FrutaToString();
    }
  }
}
