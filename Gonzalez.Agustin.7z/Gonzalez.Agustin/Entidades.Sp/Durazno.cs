using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Sp
{
  public class Durazno : Fruta
  {
    protected int _cantPelusa;

    public string Nombre
    {
      get { return "Durazno"; }
    }
    public override bool TieneCarozo
    {
      get
      {
        return true;
      }
    }
    public Durazno(string color, double peso, int cantidadPelusa) : base(color, peso)
    {
      this._cantPelusa = cantidadPelusa;
    }
    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Fruta: " + Nombre);
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Cantidad de Pelusa: " + this._cantPelusa);

      return sb.ToString();
    }
    public override string ToString()
    {
      return FrutaToString();
    }
  }
}
