using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades.Sp
{
  public delegate void CajonDelegado(object objeto, EventArgs evento);
  public class Cajon<T> : ISerializar
  {
    private int _capacidad;
    private List<T> _elementos;
    private double _precioUnitario;

    public List<T> Elementos
    {
      get { return this._elementos; }
    }

    public double PrecioTotal
    {
      get
      {
        if (this._precioUnitario > 55)
        {
          Manejador(this._precioUnitario, new EventArgs());
          this.EventoPrecio = new CajonDelegado(Manejador);
        }
        return this._precioUnitario;
      }
    }

    public Cajon()
    {
      this._elementos = new List<T>();
    }
    public Cajon(int capacidad) : this()    
    {
      this._capacidad = capacidad;
    }
    public Cajon(double precio, int capacidad): this(capacidad)        
    {
      this._precioUnitario = precio;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Capacidad del cajon: " + this._capacidad);
      sb.AppendLine("Cantidad de frutas: " + this._elementos.Count);
      sb.AppendLine("Precio total: " + this._precioUnitario);
      foreach (T item in this._elementos)
      {
       sb.AppendLine(item.ToString());
      }

      return sb.ToString();
    }

    public bool Xml(string s)
    {
      TextWriter textWriter = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + s, true);
      try
      {
        XmlSerializer serializador = new XmlSerializer(typeof(Cajon<T>));
        Cajon<T> cajon = new Cajon<T>();
        serializador.Serialize(textWriter,cajon);
      }
      catch (Exception)
      {
        return false;
      }
      finally
      {
        textWriter.Close();
      }
      return true;
    }

    public static Cajon<T> operator +(Cajon<T> cajon, T fruta)
    {
      Cajon<T> cajonNuevo = new Cajon<T>();
      cajonNuevo = cajon;
      if (cajon._capacidad > cajon._elementos.Count)
      {
        cajon._elementos.Add(fruta);
      }
      else
      {
        throw new CajonLlenoException("La capacidad " + cajonNuevo._elementos.Count + " se alcanzo!");
      }

      return cajonNuevo;
    }
    public event CajonDelegado EventoPrecio;


    public static void Manejador(object objeto, EventArgs evento)
    {
      StreamWriter textWriter = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\archivo.txt", true);
      try
      {
        DateTime fecha = DateTime.Now;
        textWriter.WriteLine(fecha.ToString() + " - Precio Total: " + ((float)objeto).ToString());
      }
      catch (Exception)
      {
      }
      textWriter.Close();
    }
  }
}
