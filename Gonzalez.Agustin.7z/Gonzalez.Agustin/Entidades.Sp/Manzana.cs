using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades.Sp
{
  public class Manzana : Fruta,ISerializar,IDeserializar
  {
    protected string _provinciaOrigen;

    public string Nombre
    {
      get { return "Manzana"; }
    }

    public override bool TieneCarozo
    {
      get
      {
         return true;
      }
    }
    public Manzana(): base("rojo",1)
    {

    }
    public Manzana (string color, double peso, string provincia) : base (color,peso)
    {
      this._provinciaOrigen = provincia;
    }
    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Fruta" + Nombre);
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Provincia de origen: " + this._provinciaOrigen);

      return sb.ToString();
    }
    public override string ToString()
    {
      return FrutaToString();
    }

    public bool Xml(string s)
    {
      TextWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + s, true);
      XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
      serializador.Serialize(escritor, this);
      escritor.Close();
      return true;
    }

    bool IDeserializar.Xml(string s, out Fruta f)
    {
      TextReader textReader = new StreamReader(AppDomain.CurrentDomain.RelativeSearchPath + s, true);
      XmlSerializer deserializador = new XmlSerializer(typeof(Manzana));
      deserializador.Deserialize(textReader);
      Fruta fruta = ((Fruta)deserializador.Deserialize(textReader));
      f = fruta;
      textReader.Close();
      return true;
    }
  }
}
