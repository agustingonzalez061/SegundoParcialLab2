﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 2";
            float num;
            float cuadrado;
            float cubo;
            Console.Write("Ingrese Numero:");
            num = int.Parse (Console.ReadLine());
            while (num < 0)
            {
                Console.Write("ERROR REINGRESE NUMERO :");
                num = float.Parse(Console.ReadLine());
            }
            cuadrado = (float)Math.Pow(num, 2);
            cubo = (float)Math.Pow(num,3);
            Console.WriteLine("El numero es: {0}\nEl Cuadrado es:{1}\nEl cubo es:{2}",num,cuadrado,cubo);
            Console.Read();
        }
    }
}
