﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase04;
namespace EjercicioClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicios clase 04";
            Cosa datos = new Cosa();

            datos.EstablecerValor("agustin Gonzalez");
            datos.EstablecerValor(19990507);
            datos.EstablecerValor(41);

            Console.WriteLine(Cosa.Mostrar(datos));
            Console.ReadLine();

        }
    }
}
