﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Cosa
    {
        #region ATRIBUTOS
        public string cadena;
        public double numero;
        public DateTime fecha;
        #endregion
        #region METODOS
        public static string Mostrar(Cosa a)
        {

            return a.Mostrar();
        }
        private string Mostrar()
        {
            return this.cadena + " " + this.numero.ToString() + " " + this.fecha.ToLongTimeString();
        }
        

        public void EstablecerValor(string a)
        {
            this.cadena=a;
        }
        public void EstablecerValor(double a)
        {
            this.numero = a;
        }
        public void EstablecerValor(DateTime a)
        {
            this.fecha = a;
        }
        #endregion
        #region CONSTRUCTOR
        public Cosa()
        {
        this.cadena = "SIN VALOR";
        this.numero = 1.9;
        this.fecha = DateTime.Now;
        }
        public Cosa(string algo) :this()
        {
            this.cadena = algo;
        }
        public Cosa(string algo, DateTime c) :this(algo)
        {
            this.fecha = DateTime.Now;
        }
        public Cosa(string algo, DateTime c, int b) : this(algo,c)
        {
            this.numero = b;
        }
        #endregion

    }
}
