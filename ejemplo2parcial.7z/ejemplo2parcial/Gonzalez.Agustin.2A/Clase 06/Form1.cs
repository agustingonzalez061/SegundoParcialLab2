using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_06
{
  public partial class Form1 : Form
  {
    private ETipoTinta _tinta;
    private Clase05.Pluma _pluma;
    private Clase05.Tinta _Tintas;
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      tintafrm tinta = new tintafrm();

      tinta.Show();
    }
  }
}
