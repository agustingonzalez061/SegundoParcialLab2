using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;

namespace EntidadesSQL
{
  public delegate void MiDelegado();
  public delegate void DelegadoTv(Televisor tv, TvEventsArgs tiempo);
  public class Televisor
  {
    public event MiDelegado MiEvento;
    public event DelegadoTv EventoTv;
    public int id;
    public string marca;
    public double precio;
    public int pulgada;
    public string pais;

    public Televisor(int id, string marca, double precio, int pulgada, string pais)
    {
      this.id = id;
      this.marca = marca;
      this.precio = precio;
      this.pulgada = pulgada;
      this.pais = pais;
    }
    public Televisor()
    {
    }
    public bool Insertar()
    {

      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();
      comando.CommandText = "Insert into televisores " + "values" + "(" + this.id + ",'" + this.marca + "'," + this.precio + "," + this.pulgada + ",'" + this.pais + "')";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        TvEventsArgs ctv = new TvEventsArgs();
        ctv.Fecha = DateTime.Now;
        this.MiEvento();
        this.EventoTv(this, ctv);
        Console.WriteLine("Agregado");
        return true;
      }
      catch (Exception)
      {
        Console.WriteLine("No agregado");
        return false;
        throw;
      }
    }
    public static bool Modificar (Televisor tv)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "UPDATE Televisores SET " + "marca= '" + tv.marca + "', " +"precio = "+ tv.precio + ", " + "pulgadas = " + tv.pulgada + ", " + "pais = '" + tv.pais + "' WHERE codigo = " + tv.id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        Console.WriteLine("Modificado");
        
        return true;
      }
      catch (Exception)
      {
        Console.WriteLine("No modificado");
        return false;
        throw;
      }
    }
    public static bool Borrar (Televisor tv)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "DELETE Televisores WHERE Codigo =" + tv.id +"";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        Console.WriteLine("borrado");
        return true;
      }
      catch (Exception)
      {
        Console.WriteLine("No borrado");
        return false;
        throw;
      }
    }
    public static List<Televisor> TraerTodos ()
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();
      comando.CommandText = "select * from Televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      try
      {
        List<Televisor> televisores = new List<Televisor>();
        conexion.Open();
        SqlDataReader lector = comando.ExecuteReader();


        while (lector.Read())
        {
          Console.BackgroundColor = ConsoleColor.Cyan;
          Console.ForegroundColor = ConsoleColor.Black;
          Console.WriteLine(lector[0] + "-" + lector[1] + "-" + lector[2] + "-" + lector[3] + "-" + lector[4]);
          televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)));
        }

        conexion.Close();
        Console.WriteLine("Trajo");
        return televisores;
      }
      catch (Exception)
      {
        Console.WriteLine("no Trajo");
        return null;
        throw;
      }
    }
    public static Televisor TraerUno(int id)
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();
      comando.CommandText = "select * from Televisores WHERE codigo = " + id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      Televisor tele= new Televisor();
      try
      {
        List<Televisor> televisores = new List<Televisor>();
        conexion.Open();
        SqlDataReader lector = comando.ExecuteReader();
        if (lector.HasRows)
        {
          while (lector.Read())
          {
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.Black;
            tele = new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4));
            Console.WriteLine(lector[0] + "-" + lector[1] + "-" + lector[2] + "-" + lector[3] + "-" + lector[4]);
          }
        }
        Console.WriteLine("Trajo");
        conexion.Close();
        return tele;
      }
      catch (Exception)
      {
        Console.WriteLine("no Treajo");
        return null;
        throw;
      }
    }
  }
}
