using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoWindowsForm
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      this.button1.Click += new EventHandler(ManejadorCentral);
      this.button1.Click += new EventHandler(MiManejadorClick);
      //this.button2.Click += new EventHandler(ManejadorCentral);
      //this.textBox1.Click += new EventHandler(ManejadorCentral);
      //this.Click += new EventHandler(MiOtroManejadorClick);
      //this.button2.Click += new EventHandler(CambiarFondo);

    }
    void MiManejadorClick (object obj, EventArgs args)
    {
      MessageBox.Show(((Control)obj).Name); //Muestra el nombbre del button.
    }
    void MiOtroManejadorClick (object obj, EventArgs args)
    {
      this.button2.Click -= new EventHandler(MiManejadorClick);
      this.button1.Click += new EventHandler(MiManejadorClick);
    }
    void CambiarFondo (object obj, EventArgs args)
    {
      (((Control)obj).BackColor) = Color.Red;
    }

    private void button3_Click(object sender, EventArgs e)
    {
      this.button1.Click -= new EventHandler(MiManejadorClick);
      this.button2.Click -= new EventHandler(MiManejadorClick);
      this.textBox1.Click -= new EventHandler(MiManejadorClick);
      this.Click -= new EventHandler(MiOtroManejadorClick);
      this.button2.Click -= new EventHandler(CambiarFondo);
    }
    void ManejadorCentral (object obj,EventArgs args)
    {
      if (obj.Equals(this.button1))
      {
        this.button1.Click -= new EventHandler(MiManejadorClick);
        this.button1.Click -= new EventHandler(ManejadorCentral);
        this.button2.Click += new EventHandler(MiManejadorClick);
        this.button2.Click += new EventHandler(ManejadorCentral);
      }
      else if (obj.Equals(this.button2))
      {
        this.button2.Click -= new EventHandler(MiManejadorClick);
        this.button2.Click -= new EventHandler(ManejadorCentral);
        this.textBox1.Click += new EventHandler(MiManejadorClick);
        this.textBox1.Click += new EventHandler(ManejadorCentral);
      }
      else if (obj.Equals(this.textBox1))
      {
        this.textBox1.Click -= new EventHandler(MiManejadorClick);
        this.textBox1.Click -= new EventHandler(ManejadorCentral);
        this.button1.Click += new EventHandler(MiManejadorClick);
        this.button1.Click += new EventHandler(ManejadorCentral);
      }
    }
  }
}
