﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesWForm
{
    public class Alumno
    {
        private string _apellido;
        private string _nombre;
        private int _dni;
        private string _fotoAlumno;

        public int Dni
        {
            get
            {
                return this._dni;
            
            }
            set
            {
                this._dni = value;
            }
        }
        public string Nombre
        {
            get
            {
                return this._nombre;

            }
            set
            {
                this._nombre = value;
            }
        }
        public string FotoAlumno
        {
            get
            {
                return this._fotoAlumno;

            }
            set
            {
                this._fotoAlumno = value;
            }
        }
        public string Apellido
        {
            get
            {
                return this._apellido;

            }
            set
            {
                this._apellido = value;
            }
        }
        public Alumno (string nombre,string apellido,string ruta,int dni)
        {
            Apellido = apellido;
            Nombre = nombre;
            FotoAlumno = ruta;
            Dni = dni;
        }

    }
}
