using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades Admin archivos
{
    class Archivos
    {
  public static AdministradorArchivos
    {
    }
}
