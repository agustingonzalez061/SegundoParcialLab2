using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase07
{
  class Tempera
  {
    #region Atributos
    private sbyte _Cantidad;
    private ConsoleColor _Color;
    private string _Marca;
    #endregion

    #region Constructor
    public Tempera()
    {
      this._Cantidad = 0;
      this._Marca = "Sin marca";
      this._Color = ConsoleColor.Cyan;
    }
    public Tempera(string marca) : this()
    {
      this._Marca = marca;
    }
    public Tempera(string marca, sbyte cant) : this(marca)
    {
      this._Cantidad = cant;
    }
    public Tempera(string marca, sbyte cant, ConsoleColor color) : this(marca, cant)
    {
      this._Color = color;
    }

    #endregion
    #region Metodos

    private string Mostrar()
    {
      string retorno = " ";
      retorno = retorno + this._Marca;
      retorno = retorno + " ";
      retorno = retorno + this._Cantidad;
      retorno = retorno + " ";
      retorno = retorno + this._Color;
      return retorno;
    }

    #endregion
    #region SobreCarga
    public static bool operator ==(Tempera obj1, Tempera obj2)
    {
      bool valor = false;
      if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
      {
        if (obj1._Color == obj2._Color && obj1._Marca == obj2._Marca)
        {
          valor = true;
        }
      }
      return valor;
    }

    public static bool operator !=(Tempera obj1, Tempera obj2)
    {

      return !(obj1 == obj2);
    }

    public static Tempera operator +(Tempera obj1, sbyte cant)
    {
      Tempera obj2 = new Tempera(obj1._Marca,(sbyte)(obj1._Cantidad + cant), obj1._Color);
      return obj2;
    }

    public static Tempera operator +(Tempera obj1, Tempera obj2)
    {
      Tempera obj3 = new Tempera(obj1._Marca, obj1._Cantidad,obj1._Color);
      if (obj1 == obj2)
      {
        obj3 += obj2._Cantidad;
      }
      return obj3;
    }
    public static implicit operator string(Tempera obj)
    {
      return obj.Mostrar();
    }
    public static explicit operator sbyte (Tempera obj)
    {
      sbyte cant = obj._Cantidad;
      return cant;
    }


    #endregion
  }
}
