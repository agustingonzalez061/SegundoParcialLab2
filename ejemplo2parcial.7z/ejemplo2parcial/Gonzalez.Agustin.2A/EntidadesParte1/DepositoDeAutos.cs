using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EntidadesParte1
{
  public class DepositoDeAutos
  {
    private int _capacidadDeposito;
    private List<Auto> _deposito;

    public DepositoDeAutos(int capacidad)
    {
      this._capacidadDeposito = capacidad;
      this._deposito = new List<Auto>(this._capacidadDeposito);
    }
    public static bool operator +(DepositoDeAutos d, Auto a)
    {
      bool valor = false;
      if (d._deposito.Count <d._capacidadDeposito)
      {
        d._deposito.Add(a);
        valor = true;
      }
      return valor;
    }
    private int GetIndice(Auto a)
    {
      int valor = -1;
      int contador = 0;
      foreach (Auto item in this._deposito)
      {
        if (item == a)
        {
          valor = contador;
          break;
        }
        contador++;
      }
      return valor;
    }
    public static bool operator -(DepositoDeAutos d, Auto a)
    {
      bool valor = false;
      int indice = d.GetIndice(a);
      if (indice != -1)
      {
        d._deposito.RemoveAt(indice);
        valor = true;
      }
      return valor;
    }
    public bool Agregar(Auto a)
    {
      return this + a;
    }
    public bool Remover(Auto a)
    {
      return this - a;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("LISTADO AUTOS");
      sb.AppendLine("capacidad :" + this._capacidadDeposito);
      foreach (Auto item in this._deposito)
      {
        sb.AppendLine(item.ToString());
      }
      return sb.ToString();
    }
    public bool Guardar (string path)
    {
      bool valor = false;
      try
      { 
      using (StreamWriter sw = new StreamWriter(path, true))
      {
        sw.WriteLine(this.ToString());
        valor = true;
      }
      }catch(Exception)
      {
        valor = false;
      }
      return valor;
    }
    public bool Recuperar(string path)
    {
      bool valor = false;
      using (StreamReader sr = new StreamReader(path, true))
      {
        sr.ReadToEnd();
        valor = true;
      }
      return valor;
    }
  }
}
