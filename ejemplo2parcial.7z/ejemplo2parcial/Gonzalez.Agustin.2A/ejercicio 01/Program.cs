﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 01";
            int num;
            int max = 0;
            int min = 0;
            int i;
            float promedio;
            int acumulador = 0;
            for (i = 0; i < 5; i ++)
            {
                Console.WriteLine("Ingrese un numero:");
                num = int.Parse (Console.ReadLine());
                acumulador = acumulador + num;
                if(i == 0)
                {
                    max = num;
                    min = num;
                }
                if (num > max)
                {
                    max = num;
                }
                if (num < min)
                {
                    min = num;
                }
            }
            promedio = acumulador /(float) i;
            Console.WriteLine("La suma es : {0}", acumulador);
            Console.WriteLine("El minimo es: {0}", min);
            Console.WriteLine("El maximo es: {0}", max);
            Console.WriteLine("El promedio es: {0:#,#.00}", promedio);

            Console.ReadLine();
        }
    }
}
