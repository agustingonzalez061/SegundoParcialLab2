using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesArchivos;

namespace ArchivosTest
{
  class Program
  {
    static void Main(string[] args)
    {
      string a;
      string b= @"D:\Mis Documentos\ArchivoTest.txt";
      string c =Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\ArchivoTest.txt";
      string d = AppDomain.CurrentDomain.BaseDirectory + @"\ArchivoTest.txt";
      if (AdministradorArchivos.Escribir(b,"xd"))
      {
        Console.WriteLine("Se pudo escribir el archivo en el d");
        if (AdministradorArchivos.Leer(b, out a))
        {
          Console.WriteLine("Se pudo leer el archivo en el d");
          if (AdministradorArchivos.Escribir(c, a))
          {
            Console.WriteLine("Se pudo escribir el archivo en escritorio");
            if (AdministradorArchivos.Leer(c, out a))
            {
              Console.WriteLine("Se pudo leer el archivo en el escritorio");
              if (AdministradorArchivos.Escribir(d, a))
              {
                Console.WriteLine("Se pudo escribir el archivo en mi locacion actual");
                if (AdministradorArchivos.Leer(d, out a))
                {
                  Console.WriteLine("Se pudo leer el archivo en mi locacion actual");
                }
                else
                {
                  Console.WriteLine("No se pudo leer el archivo");
                }
              }
              else
              {
                Console.WriteLine("No se pudo escribir el archivo");
              }
            }
            else
            {
              Console.WriteLine("No se pudo leer el archivo");
            }
          }
          else
          {
            Console.WriteLine("No se pudo escribir el archivo");
          }
        }
        else
        {
          Console.WriteLine("No se pudo leer el archivo");
        }
      }
      else
      {
        Console.WriteLine("No se pudo escribir el archivo");
      }

      Console.Read();
    }
  }
}
