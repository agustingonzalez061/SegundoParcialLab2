using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsParcial2
{
  public partial class TestDelegados : Form
  {
        private string path;
    public TestDelegados()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      string s = this.textBox1.Text;
      ((Form1)this.Owner).miDel(s);
      ((Form1)this.Owner).miDelFoto(path);
        }

    private void TestDelegados_Load(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {

    }
        private void ConfigurarOpenSaveDialog ()
        {
            this.openFileDialog1.Multiselect = false;
            this.openFileDialog1.Filter = "Archivo  de imagen (*.jpg)|*.jpg|All Files (*.*)|*.*";
            this.openFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            this.openFileDialog1.FileName = "";
            this.openFileDialog1.Title = "Seleccione una foto...";
            this.openFileDialog1.ShowDialog();
            if (!this.openFileDialog1.CheckPathExists)
            {
                MessageBox.Show("Error: El directorio no existe");
            }
            else if (!this.openFileDialog1.CheckFileExists)
            {
                MessageBox.Show("Error: El archivo no existe");
            }
            this.path= openFileDialog1.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConfigurarOpenSaveDialog();
        }
    }
}
