using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsParcial2
{
  public partial class FrmDatos : Form
  {
    public FrmDatos()
    {
      InitializeComponent();
    }

    private void FrmDatos_Load(object sender, EventArgs e)
    {

    }
    public void ActualizarNombre (string n)
    {
      this.label1.Text = n;
    }
    public void ActualizarFoto(string n)
    {
            this.pictureBox1.ImageLocation = n;
    }
    }
}
