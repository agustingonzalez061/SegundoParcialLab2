using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsParcial2
{
  public partial class Form1 : Form
  {
    public ActualizarNombrePorDelegado miDel;
    public ActualizarNombrePorDelegado miDelFoto;
    public actualizarAlumno alumno;
    public Form1()
    {
      InitializeComponent();
     
    }

    private void Form1_Load(object sender, EventArgs e)
    {
       
    }

    private void delegadosToolStripMenuItem_Click(object sender, EventArgs e)
    {
      TestDelegados frm = new TestDelegados();
      frm.Show(this);
      //this.miDel.Invoke("Probando Probando");
      //this.miDel("Probando Implicit");
      //this.miDel("");
    }

    private void alumnoToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FrmAltaAlumno formAlumno = new FrmAltaAlumno();
      formAlumno.Show(this);
    }

    private void datosToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FrmDatos frm = new FrmDatos();
      frm.Show(this);
      this.miDel +=  new ActualizarNombrePorDelegado(frm.ActualizarNombre);
      this.miDelFoto += new ActualizarNombrePorDelegado(frm.ActualizarFoto);
    }

    private void alumnosToolStripMenuItem_Click(object sender, EventArgs e)
    {
            FrmDatosAlumno formDatos = new FrmDatosAlumno();
            formDatos.Show(this);
            alumno = formDatos.ActualizarAlumno;
        }
  }
}
