using System;

public delegate void ActualizarNombrePorDelegado(string n);
public delegate void actualizarAlumno(EntidadesWForm.Alumno sender, EventArgs e);