﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesWForm;

namespace WindowsFormsParcial2
{
    public partial class FrmDatosAlumno : Form
    {
        public FrmDatosAlumno()
        {
            InitializeComponent();
        }
        public void ActualizarAlumno(Alumno sender, EventArgs e)
        {
            this.textBox1.Text = sender.Apellido;
            this.textBox3.Text = sender.Dni.ToString();
            this.textBox2.Text = sender.Nombre;
            this.textBox4.Text = sender.FotoAlumno;
            this.pictureBox1.ImageLocation = sender.FotoAlumno;
        }
    }
}
