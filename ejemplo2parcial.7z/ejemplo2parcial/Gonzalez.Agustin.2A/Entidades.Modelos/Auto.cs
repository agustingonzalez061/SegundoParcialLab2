using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Modelos
{
  public class Auto
  {
    private string _color;
    private string _marca;

    public string Color
    {
      get
      {
        return _color;
      }
    }
    public string Marca
    {
      get
      {
        return _marca;
      }
    }
    public Auto(string color, string marca)
    {
      this._marca = marca;
      this._color = color;
    }
    public static bool operator ==(Auto obj1, Auto obj2)
    {
      bool valor = false;
      if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
      {
        if (obj1._color == obj2._color && obj1._marca == obj2._marca)
        {
          valor = true;
        }
      }
      return valor;
    }
    public static bool operator !=(Auto obj1, Auto obj2)
    {
      return !(obj1 == obj2);
    }
    public override bool Equals(object obj)
    {
      bool flag = false;
      if(obj is Auto && this== ((Auto)obj))
      {
        flag = true;
      }
      return flag;
    }
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Color : " + this.Color);
      sb.AppendLine("");
      sb.AppendLine("Marca : " + this.Marca);
      sb.AppendLine("");
      sb.AppendLine("---------------------");

      return sb.ToString();
    }
  }
}
