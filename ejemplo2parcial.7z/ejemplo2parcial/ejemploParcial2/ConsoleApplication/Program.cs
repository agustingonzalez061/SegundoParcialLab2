﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApplication
{
    class Program
    {
        static bool Deserializar(ISerializable obj)
        {
            return obj.DeserializarXML();
        }
        static bool Serializar(ISerializable obj)
        {
            return obj.SerializarXML();
        }



        public event ListadoBD EventBD;

        private string ObtenerPreciosBD(ISerializable obj)
        {
            StringBuilder ret = new StringBuilder();

            SqlConnection _conexion = new SqlConnection(Properties.Settings.Default.conexion);
            SqlCommand _comando= new SqlCommand();

            _comando.Connection = _conexion;
            _comando.CommandType = CommandType.Text;
            _comando.CommandText = "SELECT * FROM PreciosFruta";

            _conexion.Open();

            SqlDataReader data = _comando.ExecuteReader();

            while (data.Read())
            {
                ret.Append("ID: " + data["id"].ToString());
                ret.Append(" - DESCRIPCION: " + data["descripcion"]);
                ret.AppendLine(" - PRECIO: "+ data["precio"]); 
            }

            data.Close();
            _conexion.Close();


            Console.WriteLine("Datos obtenidos por el delegado");

            return ret.ToString();
        }

        static void Main(string[] args)
        {
            

            Manzana m1 = new Manzana(10.5f, ConsoleColor.Red, "distr");
            Manzana m2 = new Manzana(14.5f, ConsoleColor.Red, "distrib");

            Platano pl1 = new Platano(8.5f, ConsoleColor.Yellow, "argentina");
            Platano pl2 = new Platano(9.5f, ConsoleColor.Yellow, "colombia");

            Cajon<Fruta> cajon = new Cajon<Fruta>(2, 32);

            try
            {
                cajon += m1;
                cajon += m2;
                cajon += pl1;
                cajon += pl2;
            }
            catch (CajonLlenoException e)
            {
                Console.WriteLine(e.Message);
            }


            Console.WriteLine("Datos del cajon de frutas:");
            Console.WriteLine(cajon.ToString());



            Console.WriteLine("Obteniendo datos de la BD:");
            Program p = new Program();
            Console.Write(p.ObtenerPreciosBD(cajon));
            p.EventBD = new ListadoBD(p.ObtenerPreciosBD);
            Console.WriteLine("fin de datos de la BD");


            if (Program.Serializar(cajon))
            {
                Console.WriteLine("Se pudo serializar el cajon");
            }
            else
            {
                Console.WriteLine("No se pudo serializar el cajon");
            }

            if (Program.Deserializar(cajon))
            {
                Console.WriteLine("Se pudo deserializar el cajon");
            }
            else
            {
                Console.WriteLine("No se pudo deserializar el cajon");
            }

            Console.Write("Precio total del cajon: ");
            Console.WriteLine(cajon.PrecioTotal);

            Console.Read();
        }

    }

    public delegate string ListadoBD(ISerializable obj);

}
