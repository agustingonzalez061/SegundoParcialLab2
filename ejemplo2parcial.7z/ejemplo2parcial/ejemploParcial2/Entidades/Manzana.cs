﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades
{
    public class Manzana : Fruta , ISerializable
    {
        public string distribuidora;

        public override bool TieneCarozo
        {
            get { return true; }
        }

        public string Tipo
        {
            get { return "Manzana"; }
        }

        public Manzana(float peso, ConsoleColor color, string distribuidora)
            : base(peso, color)
        {
            this.distribuidora = distribuidora;
        }


        protected override string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.FrutaToString());
            ret.AppendLine("Distribuidora: " + this.distribuidora);

            return ret.ToString();
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }






        public string RutaArchivo
        {
            get { return @"\ArchivoManzanaSerializado.xml" ;}
            set { this.RutaArchivo = this.RutaArchivo; }
        }




        bool ISerializable.SerializarXML()
        {
            TextWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + this.RutaArchivo, true);
            XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
            serializador.Serialize(escritor, this);
            escritor.Close();
            return true;
        }

        bool ISerializable.DeserializarXML()
        {
            TextReader lectura = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + this.RutaArchivo, true);
            XmlSerializer deserializador = new XmlSerializer(typeof(Manzana));
            deserializador.Deserialize(lectura);
            lectura.Close();
            return true;
        }



    }
}
